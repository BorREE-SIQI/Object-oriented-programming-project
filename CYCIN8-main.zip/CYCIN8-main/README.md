# CYCIN8

Possible issues: <br>
Issue 1: Fail to open the website via file download <br>
Solution:  <br>
After unzipping the zip file of the server, enter the following commands: <br>
$ rm -rf node_modules package-lock.json <br>
$ npm install <br>
$ npm start <br>
The local host should be working now <br>
